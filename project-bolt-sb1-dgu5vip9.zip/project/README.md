# PG Finder - India's Premier Paying Guest App

A comprehensive mobile application for finding, booking, and managing PG (Paying Guest) accommodations across India.

## 🚀 Complete Product Plan

### **Feature List**

#### **User Side Features**
- **Search & Discovery**
  - Location-based search with maps integration
  - Advanced filters (price, amenities, gender preference, room type)
  - Save favorite PGs and create wishlists
  - Recently viewed PGs

- **User Account Management**
  - Phone/Email registration and login
  - Profile management with preferences
  - Document upload for verification
  - Emergency contact information

- **Booking System**
  - Real-time availability checking
  - Multiple booking options (monthly, quarterly, yearly)
  - Online payment integration (UPI, Cards, Net Banking)
  - Booking confirmations and receipts

- **Communication**
  - In-app messaging with PG owners
  - Call integration for direct contact
  - Push notifications for booking updates

- **Reviews & Ratings**
  - Rate and review PGs after stay
  - Photo uploads with reviews
  - View other user reviews and ratings

#### **Admin/Owner Side Features**
- **Property Management**
  - Add/Edit PG listings with multiple photos
  - Room management (types, availability, pricing)
  - Amenities and facilities management
  - Virtual tours and 360° photos

- **Booking Management**
  - View and manage incoming bookings
  - Accept/Reject booking requests
  - Occupancy tracking and calendar view
  - Tenant management system

- **Financial Management**
  - Revenue tracking and analytics
  - Payment collection and tracking
  - Commission management
  - Monthly/Yearly financial reports

- **Communication Tools**
  - Chat with prospective tenants
  - Broadcast messages to current tenants
  - Automated booking confirmations

### **User Flow (Search to Booking)**

1. **Discovery**
   - User opens app → Search by location/city
   - Apply filters (budget, amenities, gender preference)
   - Browse PG listings with photos and details

2. **Exploration**
   - View detailed PG information
   - Check reviews and ratings
   - View photos and virtual tours
   - Save to favorites if interested

3. **Inquiry**
   - Contact PG owner via chat/call
   - Ask questions about availability
   - Schedule visit if needed

4. **Booking**
   - Select room type and duration
   - Fill booking form with personal details
   - Upload required documents
   - Make payment (security deposit + advance)

5. **Confirmation**
   - Receive booking confirmation
   - Get owner contact details
   - Access digital lease agreement
   - Check-in coordination

### **Tech Stack Recommendation**

#### **Frontend (Mobile App)**
- **React Native with Expo** (Current Implementation)
- **React Navigation** for navigation
- **React Native Reanimated** for animations
- **React Native Maps** for location features
- **React Native Camera** for document scanning

#### **Backend**
- **Supabase** (PostgreSQL + Real-time + Auth + Storage)
- **Supabase Edge Functions** for serverless API endpoints
- **Stripe/Razorpay** for payment processing
- **Firebase Cloud Messaging** for push notifications

#### **Additional Services**
- **Cloudinary** for image optimization and storage
- **Google Maps API** for location services
- **Twilio** for SMS notifications
- **RevenueCat** for subscription management (premium features)

### **Database Schema (Supabase)**

```sql
-- Users table
CREATE TABLE users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text UNIQUE NOT NULL,
  phone text UNIQUE NOT NULL,
  first_name text NOT NULL,
  last_name text NOT NULL,
  profile_image text,
  date_of_birth date,
  gender text CHECK (gender IN ('male', 'female', 'other')),
  occupation text,
  emergency_contact jsonb,
  preferred_location text,
  budget_range jsonb,
  is_verified boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- PG Listings table
CREATE TABLE pg_listings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id uuid REFERENCES users(id),
  name text NOT NULL,
  description text,
  type text CHECK (type IN ('boys', 'girls', 'co-ed')),
  address jsonb NOT NULL,
  pricing jsonb NOT NULL,
  amenities text[],
  rules text[],
  images text[],
  room_types jsonb,
  contact_info jsonb,
  availability jsonb,
  rating numeric(3,2) DEFAULT 0,
  review_count integer DEFAULT 0,
  is_active boolean DEFAULT true,
  is_verified boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Bookings table
CREATE TABLE bookings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(id),
  pg_id uuid REFERENCES pg_listings(id),
  room_type_id text,
  status text CHECK (status IN ('pending', 'confirmed', 'cancelled', 'completed')),
  check_in_date date NOT NULL,
  check_out_date date,
  duration integer, -- in months
  total_amount numeric(10,2),
  payment_status text CHECK (payment_status IN ('pending', 'paid', 'failed', 'refunded')),
  payment_id text,
  special_requests text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Reviews table
CREATE TABLE reviews (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(id),
  pg_id uuid REFERENCES pg_listings(id),
  booking_id uuid REFERENCES bookings(id),
  rating integer CHECK (rating >= 1 AND rating <= 5),
  comment text,
  images text[],
  owner_response jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Favorites table
CREATE TABLE favorites (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(id),
  pg_id uuid REFERENCES pg_listings(id),
  created_at timestamptz DEFAULT now(),
  UNIQUE(user_id, pg_id)
);

-- Messages table (for chat)
CREATE TABLE messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  chat_id uuid NOT NULL,
  sender_id uuid REFERENCES users(id),
  receiver_id uuid REFERENCES users(id),
  content text NOT NULL,
  type text CHECK (type IN ('text', 'image', 'location')),
  is_read boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- Chats table
CREATE TABLE chats (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  participants uuid[],
  pg_id uuid REFERENCES pg_listings(id),
  last_message_id uuid,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);
```

### **Monetization Strategy**

#### **Primary Revenue Streams**
1. **Commission Model** (15-20% from bookings)
   - Take percentage from successful bookings
   - Higher commission for premium listings

2. **Subscription Plans for Owners**
   - **Basic Plan** (₹999/month): List up to 3 properties
   - **Pro Plan** (₹2999/month): Unlimited listings + analytics
   - **Premium Plan** (₹5999/month): Priority placement + marketing tools

3. **Lead Generation Fees**
   - Charge PG owners for qualified leads
   - ₹50-100 per genuine inquiry

#### **Secondary Revenue Streams**
4. **Featured Listings**
   - Premium placement in search results
   - ₹500-1000 per week for top positioning

5. **Value-Added Services**
   - Property photography services
   - Legal document preparation
   - Insurance partnerships

6. **Advertising Revenue**
   - Local business ads (furniture, food delivery)
   - Branded content and partnerships

### **Wireframe Descriptions**

#### **Mobile App Layout**
1. **Home/Search Screen**
   - Top search bar with location input
   - City selector chips below search
   - Filter button (price, amenities, type)
   - PG cards in vertical list with image, name, location, price, rating

2. **PG Detail Screen**
   - Image carousel at top
   - PG name, location, and rating
   - Amenities grid with icons
   - Room types and pricing
   - Reviews section
   - Book Now button (sticky at bottom)

3. **Booking Flow**
   - Room selection screen
   - Date picker for check-in
   - Personal details form
   - Document upload
   - Payment screen
   - Confirmation screen

4. **Profile Screen**
   - User photo and basic info at top
   - Stats (bookings, favorites, reviews)
   - Settings menu with sections
   - Account management options

#### **Admin Dashboard Layout**
1. **Dashboard Overview**
   - Stats cards (revenue, bookings, occupancy)
   - Recent activity feed
   - Quick action buttons

2. **Property Management**
   - List of all properties with status
   - Add new property button
   - Edit/View/Analytics for each property

3. **Booking Management**
   - Calendar view of all bookings
   - Booking requests requiring action
   - Tenant management interface

### **UI Design Prompt for AI Image Generator**

"Create a modern mobile app UI design for a PG (Paying Guest) finder app targeting young professionals in India. The design should feature:

- **Color Scheme**: Primary orange (#FF6B35), secondary teal (#00A896), warm grays, and clean whites
- **Typography**: Modern, readable fonts with proper hierarchy
- **Layout**: Clean card-based design with plenty of white space
- **Components**: 
  - Search bar with location input and filter icon
  - Property cards showing room photos, name, location, price, and ratings
  - Bottom tab navigation with 5 tabs (Search, Favorites, Bookings, Profile, Admin)
  - Profile section with user stats and settings menu
- **Style**: Contemporary Indian app design with subtle shadows, rounded corners, and smooth gradients
- **Target Audience**: Young professionals aged 22-35 in metro cities
- **Mood**: Trustworthy, professional, yet approachable and user-friendly
- **Platform**: Mobile-first design optimized for Android and iOS

Include screens for: property search results, individual property details, user profile, and admin dashboard."

---

## Development Status

The app is built using React Native with Expo, featuring a modern tab-based navigation system. The current implementation includes:

- **Search functionality** with location-based filtering
- **Favorites management** with persistent storage
- **Booking tracking** with status management
- **User profile** with comprehensive settings
- **Admin dashboard** with property and analytics management

The foundation is ready for backend integration with Supabase for real-time data management and user authentication.