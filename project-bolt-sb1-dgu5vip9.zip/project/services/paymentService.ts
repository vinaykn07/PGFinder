import RazorpayCheckout from 'react-native-razorpay';
import { PaymentOptions, PaymentDetails } from '@/types/payment';

class PaymentService {
  private static instance: PaymentService;
  private supabaseUrl = process.env.EXPO_PUBLIC_SUPABASE_URL;
  private supabaseAnonKey = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY;

  static getInstance(): PaymentService {
    if (!PaymentService.instance) {
      PaymentService.instance = new PaymentService();
    }
    return PaymentService.instance;
  }

  async createOrder(amount: number, currency: string = 'INR', receipt: string, notes?: Record<string, string>) {
    try {
      const response = await fetch(`${this.supabaseUrl}/functions/v1/create-payment-order`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.supabaseAnonKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          amount: amount * 100, // Convert to paise
          currency,
          receipt,
          notes,
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to create payment order');
      }

      return await response.json();
    } catch (error) {
      console.error('Error creating payment order:', error);
      throw error;
    }
  }

  async initiatePayment(paymentOptions: PaymentOptions): Promise<any> {
    return new Promise((resolve, reject) => {
      RazorpayCheckout.open(paymentOptions)
        .then((data) => {
          // Payment successful
          resolve(data);
        })
        .catch((error) => {
          // Payment failed or cancelled
          reject(error);
        });
    });
  }

  async verifyPayment(
    razorpayOrderId: string,
    razorpayPaymentId: string,
    razorpaySignature: string,
    bookingId: string
  ) {
    try {
      const response = await fetch(`${this.supabaseUrl}/functions/v1/verify-payment`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.supabaseAnonKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          razorpay_order_id: razorpayOrderId,
          razorpay_payment_id: razorpayPaymentId,
          razorpay_signature: razorpaySignature,
          booking_id: bookingId,
        }),
      });

      if (!response.ok) {
        throw new Error('Payment verification failed');
      }

      return await response.json();
    } catch (error) {
      console.error('Error verifying payment:', error);
      throw error;
    }
  }

  async getPaymentHistory(userId: string): Promise<PaymentDetails[]> {
    try {
      const response = await fetch(`${this.supabaseUrl}/functions/v1/payment-history?user_id=${userId}`, {
        headers: {
          'Authorization': `Bearer ${this.supabaseAnonKey}`,
        },
      });

      if (!response.ok) {
        throw new Error('Failed to fetch payment history');
      }

      return await response.json();
    } catch (error) {
      console.error('Error fetching payment history:', error);
      throw error;
    }
  }

  async refundPayment(paymentId: string, amount?: number) {
    try {
      const response = await fetch(`${this.supabaseUrl}/functions/v1/refund-payment`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.supabaseAnonKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          payment_id: paymentId,
          amount: amount ? amount * 100 : undefined, // Convert to paise if partial refund
        }),
      });

      if (!response.ok) {
        throw new Error('Refund failed');
      }

      return await response.json();
    } catch (error) {
      console.error('Error processing refund:', error);
      throw error;
    }
  }
}

export default PaymentService.getInstance();