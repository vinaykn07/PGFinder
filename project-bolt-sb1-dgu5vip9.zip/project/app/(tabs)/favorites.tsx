import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
  SafeAreaView,
} from 'react-native';
import { Heart, MapPin, Star, Trash2 } from 'lucide-react-native';

const mockFavorites = [
  {
    id: 1,
    name: 'Green Valley PG',
    location: 'Koramangala, Bangalore',
    price: 12000,
    rating: 4.5,
    reviews: 23,
    image: 'https://images.pexels.com/photos/271795/pexels-photo-271795.jpeg?auto=compress&cs=tinysrgb&w=300',
    type: 'Boys',
    addedDate: '2 days ago',
  },
  {
    id: 2,
    name: 'Sunrise Ladies PG',
    location: 'HSR Layout, Bangalore',
    price: 15000,
    rating: 4.8,
    reviews: 41,
    image: 'https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg?auto=compress&cs=tinysrgb&w=300',
    type: 'Girls',
    addedDate: '1 week ago',
  },
];

export default function FavoritesScreen() {
  const [favorites, setFavorites] = useState(mockFavorites);

  const removeFavorite = (id: number) => {
    setFavorites(favorites.filter(pg => pg.id !== id));
  };

  if (favorites.length === 0) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.header}>
          <Text style={styles.title}>My Favorites</Text>
        </View>
        <View style={styles.emptyContainer}>
          <Heart size={64} color="#ccc" />
          <Text style={styles.emptyTitle}>No Favorites Yet</Text>
          <Text style={styles.emptyText}>
            Start exploring PGs and add your favorites by tapping the heart icon
          </Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>My Favorites</Text>
        <Text style={styles.subtitle}>{favorites.length} saved PGs</Text>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} style={styles.scrollView}>
        {favorites.map((pg) => (
          <View key={pg.id} style={styles.favoriteCard}>
            <Image source={{ uri: pg.image }} style={styles.pgImage} />
            <View style={styles.pgInfo}>
              <View style={styles.pgHeader}>
                <Text style={styles.pgName}>{pg.name}</Text>
                <TouchableOpacity
                  style={styles.removeButton}
                  onPress={() => removeFavorite(pg.id)}
                >
                  <Trash2 size={18} color="#FF6B35" />
                </TouchableOpacity>
              </View>
              
              <View style={styles.locationRow}>
                <MapPin size={14} color="#666" />
                <Text style={styles.pgLocation}>{pg.location}</Text>
              </View>

              <View style={styles.pgFooter}>
                <View style={styles.ratingContainer}>
                  <Star size={14} color="#FFD700" fill="#FFD700" />
                  <Text style={styles.rating}>{pg.rating}</Text>
                  <Text style={styles.reviewCount}>({pg.reviews})</Text>
                </View>
                <Text style={styles.addedDate}>Added {pg.addedDate}</Text>
              </View>

              <View style={styles.priceRow}>
                <Text style={styles.price}>₹{pg.price.toLocaleString()}/month</Text>
                <TouchableOpacity style={styles.viewButton}>
                  <Text style={styles.viewButtonText}>View Details</Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        ))}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8f9fa',
  },
  header: {
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 16,
  },
  title: {
    fontSize: 28,
    fontWeight: '700',
    color: '#2d3748',
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 16,
    color: '#666',
  },
  scrollView: {
    paddingHorizontal: 20,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 40,
  },
  emptyTitle: {
    fontSize: 24,
    fontWeight: '600',
    color: '#2d3748',
    marginTop: 16,
    marginBottom: 8,
  },
  emptyText: {
    fontSize: 16,
    color: '#666',
    textAlign: 'center',
    lineHeight: 24,
  },
  favoriteCard: {
    backgroundColor: 'white',
    borderRadius: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
    overflow: 'hidden',
  },
  pgImage: {
    width: '100%',
    height: 160,
    resizeMode: 'cover',
  },
  pgInfo: {
    padding: 16,
  },
  pgHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  pgName: {
    fontSize: 18,
    fontWeight: '600',
    color: '#2d3748',
    flex: 1,
  },
  removeButton: {
    padding: 4,
  },
  locationRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  pgLocation: {
    fontSize: 14,
    color: '#666',
    marginLeft: 6,
  },
  pgFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  rating: {
    fontSize: 14,
    fontWeight: '600',
    color: '#2d3748',
  },
  reviewCount: {
    fontSize: 12,
    color: '#666',
  },
  addedDate: {
    fontSize: 12,
    color: '#666',
  },
  priceRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  price: {
    fontSize: 18,
    fontWeight: '700',
    color: '#FF6B35',
  },
  viewButton: {
    backgroundColor: '#FF6B35',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
  },
  viewButtonText: {
    color: 'white',
    fontSize: 14,
    fontWeight: '600',
  },
});