import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  SafeAreaView,
  Dimensions,
} from 'react-native';
import { Plus, Chrome as Home, Users, Calendar, TrendingUp, DollarSign, Eye, CreditCard as Edit, MessageSquare } from 'lucide-react-native';

const { width } = Dimensions.get('window');

const mockStats = {
  totalListings: 2,
  totalBookings: 1,
  monthlyRevenue: 20000,
  occupancyRate: 78,
};

const mockListings = [
  {
    id: 1,
    name: 'Sagar PG',
    location: 'Tumkur',
    status: 'active',
    occupancy: '200/300',
    revenue: 100000,
  },
  {
    id: 2,
    name: 'Harshitha Boys Pg',
    location: 'Spt Collage, 80ft Road, Batawadifield',
    status: 'active',
    occupancy: '15/18',
    revenue: 30000,
  },
  {
    id: 3,
    name: 'City Center PG',
    location: 'MG Road',
    status: 'pending',
    occupancy: '0/25',
    revenue: 0,
  },
];

const recentActivity = [
  {
    id: 1,
    type: 'booking',
    message: 'New booking for Green Valley PG',
    time: '2 hours ago',
  },
  {
    id: 2,
    type: 'review',
    message: 'New review on Tech Hub PG (4.5 stars)',
    time: '5 hours ago',
  },
  {
    id: 3,
    type: 'inquiry',
    message: '3 new inquiries for City Center PG',
    time: '1 day ago',
  },
];

export default function AdminScreen() {
  const [activeTab, setActiveTab] = useState('dashboard');

  const StatCard = ({ icon: Icon, title, value, subtitle, color }: any) => (
    <View style={[styles.statCard, { borderLeftColor: color }]}>
      <View style={styles.statHeader}>
        <Icon size={24} color={color} />
        <Text style={styles.statTitle}>{title}</Text>
      </View>
      <Text style={styles.statValue}>{value}</Text>
      {subtitle && <Text style={styles.statSubtitle}>{subtitle}</Text>}
    </View>
  );

  const ListingCard = ({ listing }: any) => (
    <View style={styles.listingCard}>
      <View style={styles.listingHeader}>
        <View style={styles.listingInfo}>
          <Text style={styles.listingName}>{listing.name}</Text>
          <Text style={styles.listingLocation}>{listing.location}</Text>
        </View>
        <View style={[
          styles.statusBadge,
          { backgroundColor: listing.status === 'active' ? '#00A896' : '#FFB800' }
        ]}>
          <Text style={styles.statusText}>{listing.status}</Text>
        </View>
      </View>
      
      <View style={styles.listingStats}>
        <View style={styles.listingStat}>
          <Text style={styles.listingStatValue}>{listing.occupancy}</Text>
          <Text style={styles.listingStatLabel}>Occupancy</Text>
        </View>
        <View style={styles.listingStat}>
          <Text style={styles.listingStatValue}>₹{listing.revenue.toLocaleString()}</Text>
          <Text style={styles.listingStatLabel}>Revenue</Text>
        </View>
      </View>

      <View style={styles.listingActions}>
        <TouchableOpacity style={styles.actionButton}>
          <Eye size={16} color="#666" />
          <Text style={styles.actionText}>View</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.actionButton}>
          <Edit size={16} color="#666" />
          <Text style={styles.actionText}>Edit</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.actionButton}>
          <MessageSquare size={16} color="#666" />
          <Text style={styles.actionText}>Messages</Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <View>
          <Text style={styles.title}>Admin Dashboard</Text>
          <Text style={styles.subtitle}>Manage your PG properties</Text>
        </View>
        <TouchableOpacity style={styles.addButton}>
          <Plus size={20} color="white" />
        </TouchableOpacity>
      </View>

      {/* Tab Navigation */}
      <View style={styles.tabContainer}>
        <TouchableOpacity
          style={[styles.tab, activeTab === 'dashboard' && styles.activeTab]}
          onPress={() => setActiveTab('dashboard')}
        >
          <Text style={[styles.tabText, activeTab === 'dashboard' && styles.activeTabText]}>
            Dashboard
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.tab, activeTab === 'listings' && styles.activeTab]}
          onPress={() => setActiveTab('listings')}
        >
          <Text style={[styles.tabText, activeTab === 'listings' && styles.activeTabText]}>
            Listings
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.tab, activeTab === 'analytics' && styles.activeTab]}
          onPress={() => setActiveTab('analytics')}
        >
          <Text style={[styles.tabText, activeTab === 'analytics' && styles.activeTabText]}>
            Analytics
          </Text>
        </TouchableOpacity>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} style={styles.content}>
        {activeTab === 'dashboard' && (
          <>
            {/* Stats Grid */}
            <View style={styles.statsGrid}>
              <StatCard
                icon={Home}
                title="Total Listings"
                value={mockStats.totalListings}
                color="#FF6B35"
              />
              <StatCard
                icon={Calendar}
                title="Total Bookings"
                value={mockStats.totalBookings}
                color="#00A896"
              />
              <StatCard
                icon={DollarSign}
                title="Monthly Revenue"
                value={`₹${(mockStats.monthlyRevenue / 1000)}K`}
                color="#FFB800"
              />
              <StatCard
                icon={TrendingUp}
                title="Occupancy Rate"
                value={`${mockStats.occupancyRate}%`}
                color="#9333EA"
              />
            </View>

            {/* Recent Activity */}
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Recent Activity</Text>
              <View style={styles.activityContainer}>
                {recentActivity.map((activity) => (
                  <View key={activity.id} style={styles.activityItem}>
                    <View style={styles.activityIcon}>
                      <Calendar size={16} color="#666" />
                    </View>
                    <View style={styles.activityContent}>
                      <Text style={styles.activityMessage}>{activity.message}</Text>
                      <Text style={styles.activityTime}>{activity.time}</Text>
                    </View>
                  </View>
                ))}
              </View>
            </View>
          </>
        )}

        {activeTab === 'listings' && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Your Properties</Text>
            {mockListings.map((listing) => (
              <ListingCard key={listing.id} listing={listing} />
            ))}
          </View>
        )}

        {activeTab === 'analytics' && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Performance Analytics</Text>
            <View style={styles.analyticsCard}>
              <Text style={styles.analyticsTitle}>This Month</Text>
              <View style={styles.analyticsStats}>
                <View style={styles.analyticsStat}>
                  <Text style={styles.analyticsValue}>24</Text>
                  <Text style={styles.analyticsLabel}>New Bookings</Text>
                </View>
                <View style={styles.analyticsStat}>
                  <Text style={styles.analyticsValue}>₹1.8L</Text>
                  <Text style={styles.analyticsLabel}>Revenue</Text>
                </View>
                <View style={styles.analyticsStat}>
                  <Text style={styles.analyticsValue}>4.6</Text>
                  <Text style={styles.analyticsLabel}>Avg Rating</Text>
                </View>
              </View>
            </View>
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8f9fa',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 16,
    backgroundColor: 'white',
  },
  title: {
    fontSize: 28,
    fontWeight: '700',
    color: '#2d3748',
  },
  subtitle: {
    fontSize: 14,
    color: '#666',
    marginTop: 2,
  },
  addButton: {
    backgroundColor: '#FF6B35',
    borderRadius: 12,
    padding: 12,
  },
  tabContainer: {
    flexDirection: 'row',
    backgroundColor: 'white',
    paddingHorizontal: 20,
    paddingBottom: 20,
  },
  tab: {
    flex: 1,
    paddingVertical: 12,
    alignItems: 'center',
    backgroundColor: '#f1f5f9',
    marginHorizontal: 2,
    borderRadius: 8,
  },
  activeTab: {
    backgroundColor: '#FF6B35',
  },
  tabText: {
    fontSize: 14,
    fontWeight: '500',
    color: '#666',
  },
  activeTabText: {
    color: 'white',
    fontWeight: '600',
  },
  content: {
    paddingHorizontal: 20,
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    marginBottom: 24,
  },
  statCard: {
    backgroundColor: 'white',
    borderRadius: 16,
    padding: 16,
    width: (width - 52) / 2,
    borderLeftWidth: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  statHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 8,
  },
  statTitle: {
    fontSize: 12,
    color: '#666',
    fontWeight: '500',
  },
  statValue: {
    fontSize: 24,
    fontWeight: '700',
    color: '#2d3748',
  },
  statSubtitle: {
    fontSize: 12,
    color: '#666',
    marginTop: 2,
  },
  section: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#2d3748',
    marginBottom: 16,
  },
  activityContainer: {
    backgroundColor: 'white',
    borderRadius: 16,
    overflow: 'hidden',
  },
  activityItem: {
    flexDirection: 'row',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#f1f5f9',
  },
  activityIcon: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#f8f9fa',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  activityContent: {
    flex: 1,
  },
  activityMessage: {
    fontSize: 14,
    color: '#2d3748',
    marginBottom: 2,
  },
  activityTime: {
    fontSize: 12,
    color: '#666',
  },
  listingCard: {
    backgroundColor: 'white',
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  listingHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  listingInfo: {
    flex: 1,
  },
  listingName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#2d3748',
    marginBottom: 2,
  },
  listingLocation: {
    fontSize: 14,
    color: '#666',
  },
  statusBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
  },
  statusText: {
    fontSize: 12,
    color: 'white',
    fontWeight: '500',
    textTransform: 'capitalize',
  },
  listingStats: {
    flexDirection: 'row',
    gap: 24,
    marginBottom: 16,
  },
  listingStat: {
    flex: 1,
  },
  listingStatValue: {
    fontSize: 16,
    fontWeight: '700',
    color: '#2d3748',
    marginBottom: 2,
  },
  listingStatLabel: {
    fontSize: 12,
    color: '#666',
  },
  listingActions: {
    flexDirection: 'row',
    gap: 12,
  },
  actionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 12,
    paddingVertical: 8,
    backgroundColor: '#f8f9fa',
    borderRadius: 8,
  },
  actionText: {
    fontSize: 12,
    color: '#666',
    fontWeight: '500',
  },
  analyticsCard: {
    backgroundColor: 'white',
    borderRadius: 16,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  analyticsTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#2d3748',
    marginBottom: 16,
  },
  analyticsStats: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  analyticsStat: {
    alignItems: 'center',
  },
  analyticsValue: {
    fontSize: 20,
    fontWeight: '700',
    color: '#FF6B35',
    marginBottom: 4,
  },
  analyticsLabel: {
    fontSize: 12,
    color: '#666',
  },
});