import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
  SafeAreaView,
} from 'react-native';
import { Calendar, MapPin, Phone, MessageCircle, Clock, CircleCheck as CheckCircle, Circle as XCircle } from 'lucide-react-native';

const mockBookings = [
  {
    id: 1,
    pgName: 'Green Valley PG',
    location: 'Koramangala, Bangalore',
    image: 'https://www.justdial.com/Tumkur/Sagar-Paying-Guest-Near-Adishwar-Electronics-Ashok-Nagar-Tumkur/9999PX816-X816-170627182013-N6K2_BZDET#',
    checkIn: '15 Jan 2025',
    checkOut: '15 Jul 2025',
    status: 'confirmed',
    amount: 5000,
    bookingId: 'PG2025001',
    ownerPhone: '+91 8088048896',
  },
  {
    id: 2,
    pgName: 'Shri Sai Pg',
    location: 'Backgate, Tumkur',
    image: 'https://www.justdial.com/Tumkur/Shri-Sai-Pg-Tumkur-University-Opposite-Ashok-Nagar-Tumkur/9999PX816-X816-171206215829-Q4C6_BZDET#',
    checkIn: '01 Feb 2025',
    checkOut: '01 Aug 2025',
    status: 'pending',
    amount: 6000,
    bookingId: 'PG2025002',
    ownerPhone: '+91 9008477413',
  },
];

const getStatusIcon = (status: string) => {
  switch (status) {
    case 'confirmed':
      return <CheckCircle size={16} color="#00A896" />;
    case 'pending':
      return <Clock size={16} color="#FFB800" />;
    case 'cancelled':
      return <XCircle size={16} color="#FF6B35" />;
    default:
      return null;
  }
};

const getStatusColor = (status: string) => {
  switch (status) {
    case 'confirmed':
      return '#00A896';
    case 'pending':
      return '#FFB800';
    case 'cancelled':
      return '#FF6B35';
    default:
      return '#666';
  }
};

export default function BookingsScreen() {
  const [activeTab, setActiveTab] = useState('current');

  const filteredBookings = mockBookings.filter(booking => {
    if (activeTab === 'current') return booking.status !== 'cancelled';
    if (activeTab === 'past') return booking.status === 'cancelled';
    return true;
  });

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>My Bookings</Text>
        
        {/* Tab Selector */}
        <View style={styles.tabContainer}>
          <TouchableOpacity
            style={[styles.tab, activeTab === 'current' && styles.activeTab]}
            onPress={() => setActiveTab('current')}
          >
            <Text style={[styles.tabText, activeTab === 'current' && styles.activeTabText]}>
              Current
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.tab, activeTab === 'past' && styles.activeTab]}
            onPress={() => setActiveTab('past')}
          >
            <Text style={[styles.tabText, activeTab === 'past' && styles.activeTabText]}>
              Past
            </Text>
          </TouchableOpacity>
        </View>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} style={styles.scrollView}>
        {filteredBookings.length === 0 ? (
          <View style={styles.emptyContainer}>
            <Calendar size={64} color="#ccc" />
            <Text style={styles.emptyTitle}>No Bookings</Text>
            <Text style={styles.emptyText}>
              {activeTab === 'current' 
                ? "You don't have any current bookings. Start exploring PGs!"
                : "No past bookings to show."
              }
            </Text>
          </View>
        ) : (
          filteredBookings.map((booking) => (
            <View key={booking.id} style={styles.bookingCard}>
              <Image source={{ uri: booking.image }} style={styles.pgImage} />
              <View style={styles.bookingInfo}>
                <View style={styles.bookingHeader}>
                  <Text style={styles.pgName}>{booking.pgName}</Text>
                  <View style={styles.statusContainer}>
                    {getStatusIcon(booking.status)}
                    <Text style={[styles.status, { color: getStatusColor(booking.status) }]}>
                      {booking.status.charAt(0).toUpperCase() + booking.status.slice(1)}
                    </Text>
                  </View>
                </View>

                <View style={styles.locationRow}>
                  <MapPin size={14} color="#666" />
                  <Text style={styles.location}>{booking.location}</Text>
                </View>

                <View style={styles.dateContainer}>
                  <View style={styles.dateItem}>
                    <Text style={styles.dateLabel}>Check-in</Text>
                    <Text style={styles.dateValue}>{booking.checkIn}</Text>
                  </View>
                  <View style={styles.dateItem}>
                    <Text style={styles.dateLabel}>Check-out</Text>
                    <Text style={styles.dateValue}>{booking.checkOut}</Text>
                  </View>
                </View>

                <View style={styles.bookingFooter}>
                  <View style={styles.amountContainer}>
                    <Text style={styles.bookingId}>#{booking.bookingId}</Text>
                    <Text style={styles.amount}>₹{booking.amount.toLocaleString()}</Text>
                  </View>
                  
                  <View style={styles.actionButtons}>
                    <TouchableOpacity style={styles.phoneButton}>
                      <Phone size={16} color="white" />
                    </TouchableOpacity>
                    <TouchableOpacity style={styles.chatButton}>
                      <MessageCircle size={16} color="white" />
                    </TouchableOpacity>
                  </View>
                </View>
              </View>
            </View>
          ))
        )}

        {/* Support Banner */}
        <View style={styles.supportBanner}>
          <Text style={styles.supportTitle}>Need Help?</Text>
          <Text style={styles.supportText}>Contact our support team for booking assistance</Text>
          <TouchableOpacity style={styles.supportButton}>
            <Text style={styles.supportButtonText}>Get Support</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8f9fa',
  },
  header: {
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 16,
  },
  title: {
    fontSize: 28,
    fontWeight: '700',
    color: '#2d3748',
    marginBottom: 16,
  },
  tabContainer: {
    flexDirection: 'row',
    backgroundColor: '#e2e8f0',
    borderRadius: 12,
    padding: 4,
  },
  tab: {
    flex: 1,
    paddingVertical: 12,
    alignItems: 'center',
    borderRadius: 8,
  },
  activeTab: {
    backgroundColor: 'white',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  tabText: {
    fontSize: 14,
    fontWeight: '500',
    color: '#666',
  },
  activeTabText: {
    color: '#2d3748',
    fontWeight: '600',
  },
  scrollView: {
    paddingHorizontal: 20,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 40,
    paddingTop: 100,
  },
  emptyTitle: {
    fontSize: 24,
    fontWeight: '600',
    color: '#2d3748',
    marginTop: 16,
    marginBottom: 8,
  },
  emptyText: {
    fontSize: 16,
    color: '#666',
    textAlign: 'center',
    lineHeight: 24,
  },
  bookingCard: {
    backgroundColor: 'white',
    borderRadius: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
    overflow: 'hidden',
  },
  pgImage: {
    width: '100%',
    height: 140,
    resizeMode: 'cover',
  },
  bookingInfo: {
    padding: 16,
  },
  bookingHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  pgName: {
    fontSize: 18,
    fontWeight: '600',
    color: '#2d3748',
    flex: 1,
  },
  statusContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  status: {
    fontSize: 12,
    fontWeight: '600',
    textTransform: 'capitalize',
  },
  locationRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  location: {
    fontSize: 14,
    color: '#666',
    marginLeft: 6,
  },
  dateContainer: {
    flexDirection: 'row',
    gap: 24,
    marginBottom: 16,
  },
  dateItem: {
    flex: 1,
  },
  dateLabel: {
    fontSize: 12,
    color: '#666',
    marginBottom: 4,
  },
  dateValue: {
    fontSize: 14,
    fontWeight: '600',
    color: '#2d3748',
  },
  bookingFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  amountContainer: {
    flex: 1,
  },
  bookingId: {
    fontSize: 12,
    color: '#666',
    marginBottom: 4,
  },
  amount: {
    fontSize: 18,
    fontWeight: '700',
    color: '#FF6B35',
  },
  actionButtons: {
    flexDirection: 'row',
    gap: 8,
  },
  phoneButton: {
    backgroundColor: '#00A896',
    borderRadius: 8,
    padding: 8,
  },
  chatButton: {
    backgroundColor: '#FF6B35',
    borderRadius: 8,
    padding: 8,
  },
  supportBanner: {
    backgroundColor: '#2d3748',
    margin: 20,
    padding: 20,
    borderRadius: 16,
    alignItems: 'center',
  },
  supportTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: 'white',
    marginBottom: 8,
  },
  supportText: {
    fontSize: 14,
    color: 'white',
    textAlign: 'center',
    marginBottom: 16,
    opacity: 0.9,
  },
  supportButton: {
    backgroundColor: '#FF6B35',
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 8,
  },
  supportButtonText: {
    color: 'white',
    fontSize: 14,
    fontWeight: '600',
  },
});