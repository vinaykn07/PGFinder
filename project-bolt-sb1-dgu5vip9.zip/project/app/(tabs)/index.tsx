import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TextInput,
  TouchableOpacity,
  Image,
  SafeAreaView,
} from 'react-native';
import { Search, MapPin, Filter, Star, Wifi, Car, Coffee, Shield } from 'lucide-react-native';

const mockPGData = [
  {
    id: 1,
    name: 'Green Valley PG',
    location: 'Koramangala, Bangalore',
    price: 12000,
    rating: 4.5,
    reviews: 23,
    image: 'https://images.pexels.com/photos/271795/pexels-photo-271795.jpeg?auto=compress&cs=tinysrgb&w=300',
    amenities: ['WiFi', 'Parking', 'Meals', 'Security'],
    type: 'Boys',
  },
  {
    id: 2,
    name: 'Sunrise Ladies PG',
    location: 'HSR Layout, Bangalore',
    price: 15000,
    rating: 4.8,
    reviews: 41,
    image: 'https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg?auto=compress&cs=tinysrgb&w=300',
    amenities: ['WiFi', 'Meals', 'Laundry', 'Security'],
    type: 'Girls',
  },
  {
    id: 3,
    name: 'Tech Hub PG',
    location: 'Whitefield, Bangalore',
    price: 10000,
    rating: 4.2,
    reviews: 18,
    image: 'https://images.pexels.com/photos/1643383/pexels-photo-1643383.jpeg?auto=compress&cs=tinysrgb&w=300',
    amenities: ['WiFi', 'Parking', 'Gym', 'Security'],
    type: 'Boys',
  },
];

const cities = ['Bangalore', 'Mumbai', 'Delhi', 'Pune', 'Chennai', 'Hyderabad'];

export default function SearchScreen() {
  const [searchLocation, setSearchLocation] = useState('');
  const [selectedCity, setSelectedCity] = useState('Bangalore');
  const [showFilters, setShowFilters] = useState(false);

  const getAmenityIcon = (amenity: string) => {
    switch (amenity) {
      case 'WiFi':
        return <Wifi size={14} color="#00A896" />;
      case 'Parking':
        return <Car size={14} color="#00A896" />;
      case 'Meals':
        return <Coffee size={14} color="#00A896" />;
      case 'Security':
        return <Shield size={14} color="#00A896" />;
      default:
        return null;
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.greeting}>Find Your Perfect PG</Text>
          <Text style={styles.subGreeting}>Comfortable stays across India</Text>
        </View>

        {/* Search Bar */}
        <View style={styles.searchContainer}>
          <View style={styles.searchBar}>
            <Search size={20} color="#666" />
            <TextInput
              style={styles.searchInput}
              placeholder="Search by location, area, landmark..."
              value={searchLocation}
              onChangeText={setSearchLocation}
              placeholderTextColor="#999"
            />
          </View>
          <TouchableOpacity
            style={styles.filterButton}
            onPress={() => setShowFilters(!showFilters)}
          >
            <Filter size={20} color="white" />
          </TouchableOpacity>
        </View>

        {/* City Selector */}
        <View style={styles.cityContainer}>
          <Text style={styles.sectionTitle}>Popular Cities</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            <View style={styles.cityList}>
              {cities.map((city) => (
                <TouchableOpacity
                  key={city}
                  style={[
                    styles.cityChip,
                    selectedCity === city && styles.cityChipActive,
                  ]}
                  onPress={() => setSelectedCity(city)}
                >
                  <Text
                    style={[
                      styles.cityText,
                      selectedCity === city && styles.cityTextActive,
                    ]}
                  >
                    {city}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </ScrollView>
        </View>

        {/* Quick Filters */}
        {showFilters && (
          <View style={styles.quickFilters}>
            <Text style={styles.sectionTitle}>Quick Filters</Text>
            <View style={styles.filterRow}>
              <TouchableOpacity style={styles.filterChip}>
                <Text style={styles.filterText}>Boys Only</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.filterChip}>
                <Text style={styles.filterText}>Girls Only</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.filterChip}>
                <Text style={styles.filterText}>Under ₹15K</Text>
              </TouchableOpacity>
            </View>
            <View style={styles.filterRow}>
              <TouchableOpacity style={styles.filterChip}>
                <Text style={styles.filterText}>With Meals</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.filterChip}>
                <Text style={styles.filterText}>WiFi</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.filterChip}>
                <Text style={styles.filterText}>Parking</Text>
              </TouchableOpacity>
            </View>
          </View>
        )}

        {/* PG Listings */}
        <View style={styles.listingsContainer}>
          <View style={styles.listingsHeader}>
            <Text style={styles.sectionTitle}>Available PGs in {selectedCity}</Text>
            <Text style={styles.resultsCount}>{mockPGData.length} results</Text>
          </View>

          {mockPGData.map((pg) => (
            <TouchableOpacity key={pg.id} style={styles.pgCard}>
              <Image source={{ uri: pg.image }} style={styles.pgImage} />
              <View style={styles.pgInfo}>
                <View style={styles.pgHeader}>
                  <Text style={styles.pgName}>{pg.name}</Text>
                  <Text style={styles.pgType}>{pg.type}</Text>
                </View>
                
                <View style={styles.locationRow}>
                  <MapPin size={14} color="#666" />
                  <Text style={styles.pgLocation}>{pg.location}</Text>
                </View>

                <View style={styles.amenitiesRow}>
                  {pg.amenities.slice(0, 4).map((amenity, index) => (
                    <View key={index} style={styles.amenityItem}>
                      {getAmenityIcon(amenity)}
                      <Text style={styles.amenityText}>{amenity}</Text>
                    </View>
                  ))}
                </View>

                <View style={styles.pgFooter}>
                  <View style={styles.ratingContainer}>
                    <Star size={14} color="#FFD700" fill="#FFD700" />
                    <Text style={styles.rating}>{pg.rating}</Text>
                    <Text style={styles.reviewCount}>({pg.reviews} reviews)</Text>
                  </View>
                  <View style={styles.priceContainer}>
                    <Text style={styles.price}>₹{pg.price.toLocaleString()}</Text>
                    <Text style={styles.priceLabel}>/month</Text>
                  </View>
                </View>
              </View>
            </TouchableOpacity>
          ))}
        </View>

        {/* Banner */}
        <View style={styles.banner}>
          <Text style={styles.bannerTitle}>List Your PG</Text>
          <Text style={styles.bannerText}>Earn up to ₹50,000/month by listing your property</Text>
          <TouchableOpacity style={styles.bannerButton}>
            <Text style={styles.bannerButtonText}>Get Started</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8f9fa',
  },
  header: {
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 16,
  },
  greeting: {
    fontSize: 28,
    fontWeight: '700',
    color: '#2d3748',
    marginBottom: 4,
  },
  subGreeting: {
    fontSize: 16,
    color: '#666',
  },
  searchContainer: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    marginBottom: 20,
    gap: 12,
  },
  searchBar: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'white',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  searchInput: {
    flex: 1,
    marginLeft: 12,
    fontSize: 16,
    color: '#2d3748',
  },
  filterButton: {
    backgroundColor: '#FF6B35',
    borderRadius: 12,
    padding: 12,
    justifyContent: 'center',
    alignItems: 'center',
  },
  cityContainer: {
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#2d3748',
    paddingHorizontal: 20,
    marginBottom: 12,
  },
  cityList: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    gap: 12,
  },
  cityChip: {
    backgroundColor: 'white',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  cityChipActive: {
    backgroundColor: '#FF6B35',
    borderColor: '#FF6B35',
  },
  cityText: {
    fontSize: 14,
    color: '#666',
    fontWeight: '500',
  },
  cityTextActive: {
    color: 'white',
  },
  quickFilters: {
    paddingHorizontal: 20,
    marginBottom: 20,
  },
  filterRow: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 8,
  },
  filterChip: {
    backgroundColor: 'white',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  filterText: {
    fontSize: 12,
    color: '#666',
  },
  listingsContainer: {
    paddingHorizontal: 20,
  },
  listingsHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  resultsCount: {
    fontSize: 14,
    color: '#666',
  },
  pgCard: {
    backgroundColor: 'white',
    borderRadius: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
    overflow: 'hidden',
  },
  pgImage: {
    width: '100%',
    height: 200,
    resizeMode: 'cover',
  },
  pgInfo: {
    padding: 16,
  },
  pgHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  pgName: {
    fontSize: 18,
    fontWeight: '600',
    color: '#2d3748',
    flex: 1,
  },
  pgType: {
    backgroundColor: '#FF6B35',
    color: 'white',
    fontSize: 12,
    fontWeight: '500',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
  },
  locationRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  pgLocation: {
    fontSize: 14,
    color: '#666',
    marginLeft: 6,
  },
  amenitiesRow: {
    flexDirection: 'row',
    gap: 16,
    marginBottom: 16,
  },
  amenityItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  amenityText: {
    fontSize: 12,
    color: '#666',
  },
  pgFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  rating: {
    fontSize: 14,
    fontWeight: '600',
    color: '#2d3748',
  },
  reviewCount: {
    fontSize: 12,
    color: '#666',
  },
  priceContainer: {
    flexDirection: 'row',
    alignItems: 'baseline',
    gap: 2,
  },
  price: {
    fontSize: 20,
    fontWeight: '700',
    color: '#FF6B35',
  },
  priceLabel: {
    fontSize: 12,
    color: '#666',
  },
  banner: {
    backgroundColor: '#00A896',
    margin: 20,
    padding: 20,
    borderRadius: 16,
    alignItems: 'center',
  },
  bannerTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: 'white',
    marginBottom: 8,
  },
  bannerText: {
    fontSize: 14,
    color: 'white',
    textAlign: 'center',
    marginBottom: 16,
    opacity: 0.9,
  },
  bannerButton: {
    backgroundColor: 'white',
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 8,
  },
  bannerButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#00A896',
  },
});