export interface User {
  id: string;
  email: string;
  phone: string;
  firstName: string;
  lastName: string;
  profileImage?: string;
  dateOfBirth?: string;
  gender: 'male' | 'female' | 'other';
  occupation?: string;
  emergencyContact: {
    name: string;
    phone: string;
    relationship: string;
  };
  preferredLocation?: string;
  budgetRange: {
    min: number;
    max: number;
  };
  createdAt: string;
  updatedAt: string;
}

export interface PGListing {
  id: string;
  ownerId: string;
  name: string;
  description: string;
  type: 'boys' | 'girls' | 'co-ed';
  address: {
    street: string;
    area: string;
    city: string;
    state: string;
    pincode: string;
    coordinates: {
      latitude: number;
      longitude: number;
    };
  };
  pricing: {
    rent: number;
    securityDeposit: number;
    maintenanceCharges?: number;
    electricityCharges?: number;
  };
  amenities: string[];
  rules: string[];
  images: string[];
  roomTypes: RoomType[];
  contactInfo: {
    ownerName: string;
    phone: string;
    email?: string;
  };
  availability: {
    totalRooms: number;
    availableRooms: number;
  };
  rating: number;
  reviewCount: number;
  isActive: boolean;
  isVerified: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface RoomType {
  id: string;
  type: 'single' | 'double' | 'triple';
  rent: number;
  availableCount: number;
  totalCount: number;
  features: string[];
}

export interface Booking {
  id: string;
  userId: string;
  pgId: string;
  roomTypeId: string;
  status: 'pending' | 'confirmed' | 'cancelled' | 'completed';
  checkInDate: string;
  checkOutDate?: string;
  duration: number; // in months
  totalAmount: number;
  paymentStatus: 'pending' | 'paid' | 'failed' | 'refunded';
  paymentId?: string;
  specialRequests?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Review {
  id: string;
  userId: string;
  pgId: string;
  bookingId: string;
  rating: number;
  comment: string;
  images?: string[];
  ownerResponse?: {
    comment: string;
    createdAt: string;
  };
  createdAt: string;
  updatedAt: string;
}

export interface Favorite {
  id: string;
  userId: string;
  pgId: string;
  createdAt: string;
}

export interface Message {
  id: string;
  senderId: string;
  receiverId: string;
  content: string;
  type: 'text' | 'image' | 'location';
  isRead: boolean;
  createdAt: string;
}

export interface Chat {
  id: string;
  participants: string[];
  pgId?: string;
  lastMessage?: Message;
  createdAt: string;
  updatedAt: string;
}