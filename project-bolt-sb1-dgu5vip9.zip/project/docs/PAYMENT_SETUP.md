# Razorpay Payment Integration Setup Guide

## 1. Create Razorpay Account

1. Visit [Razorpay Dashboard](https://dashboard.razorpay.com/signup)
2. Sign up with your business details
3. Complete KYC verification for live payments
4. Navigate to Settings → API Keys

## 2. Get API Credentials

### Test Mode (for development)
- **Key ID**: `rzp_test_xxxxxxxxxx`
- **Key Secret**: `xxxxxxxxxx`

### Live Mode (for production)
- **Key ID**: `rzp_live_xxxxxxxxxx`
- **Key Secret**: `xxxxxxxxxx`

## 3. Environment Variables Setup

Add these to your `.env` file:

```env
# Razorpay Configuration
EXPO_PUBLIC_RAZORPAY_KEY_ID=rzp_test_xxxxxxxxxx
RAZORPAY_KEY_SECRET=your_secret_key_here
RAZORPAY_WEBHOOK_SECRET=your_webhook_secret_here
```

## 4. Webhook Configuration

1. Go to Razorpay Dashboard → Settings → Webhooks
2. Add webhook URL: `https://your-project.supabase.co/functions/v1/razorpay-webhook`
3. Select events:
   - `payment.captured`
   - `payment.failed`
   - `order.paid`
   - `refund.created`
4. Copy the webhook secret and add to environment variables

## 5. Test Card Numbers

### Successful Payments
- **Card Number**: `4111111111111111`
- **CVV**: `123`
- **Expiry**: Any future date
- **Name**: Any name

### Failed Payments
- **Card Number**: `4000000000000002`
- **CVV**: `123`
- **Expiry**: Any future date

### UPI Testing
- **UPI ID**: `success@razorpay`
- **UPI ID (failure)**: `failure@razorpay`

## 6. Security Best Practices

### API Key Security
- ✅ Store secret keys in environment variables only
- ✅ Never expose secret keys in frontend code
- ✅ Use different keys for test and production
- ✅ Rotate keys regularly

### Payment Verification
- ✅ Always verify payments on the server side
- ✅ Use webhook signature verification
- ✅ Implement idempotency for webhook handling
- ✅ Log all payment events for audit

### Data Protection
- ✅ Never store card details in your database
- ✅ Use HTTPS for all payment communications
- ✅ Implement proper error handling
- ✅ Follow PCI DSS compliance guidelines

## 7. Production Checklist

Before going live:

- [ ] Complete Razorpay KYC verification
- [ ] Switch to live API keys
- [ ] Test all payment flows thoroughly
- [ ] Set up proper error monitoring
- [ ] Configure webhook endpoints
- [ ] Implement refund handling
- [ ] Set up payment reconciliation
- [ ] Add proper logging and analytics

## 8. Common Issues & Solutions

### Payment Gateway Not Opening
- Check if Razorpay key ID is correct
- Ensure amount is in paise (multiply by 100)
- Verify network connectivity

### Signature Verification Failed
- Check webhook secret configuration
- Ensure proper HMAC SHA256 implementation
- Verify request body is not modified

### Webhook Not Receiving Events
- Check webhook URL is accessible
- Verify SSL certificate is valid
- Ensure proper CORS headers

## 9. Support & Documentation

- [Razorpay Documentation](https://razorpay.com/docs/)
- [React Native Integration](https://razorpay.com/docs/payments/payment-gateway/react-native-integration/)
- [Webhook Guide](https://razorpay.com/docs/webhooks/)
- [Test Cards](https://razorpay.com/docs/payments/payments/test-card-upi-details/)

## 10. Monitoring & Analytics

Track these metrics:
- Payment success rate
- Average transaction value
- Popular payment methods
- Failed payment reasons
- Refund rates
- Revenue trends

Use Razorpay Dashboard analytics and implement custom tracking in your app for comprehensive insights.