/*
  # Payment System Schema

  1. New Tables
    - `payment_orders` - Stores Razorpay order information
    - `payments` - Stores completed payment transactions
    - `refunds` - Stores refund transactions
    - `payment_logs` - Stores payment-related logs for debugging
    - `webhook_logs` - Stores webhook events from Razorpay

  2. Security
    - Enable RLS on all payment tables
    - Add policies for users to view their own payment data
    - Admin policies for managing all payment data

  3. Features
    - Complete payment tracking from order creation to completion
    - Refund management with partial/full refund support
    - Comprehensive logging for debugging and audit trails
    - Webhook event tracking for real-time payment updates
*/

-- Payment Orders Table
CREATE TABLE IF NOT EXISTS payment_orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  razorpay_order_id text UNIQUE NOT NULL,
  amount numeric(10,2) NOT NULL,
  currency text DEFAULT 'INR',
  receipt text NOT NULL,
  status text CHECK (status IN ('created', 'attempted', 'paid')) DEFAULT 'created',
  notes jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Payments Table
CREATE TABLE IF NOT EXISTS payments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_id uuid REFERENCES bookings(id),
  razorpay_order_id text NOT NULL,
  razorpay_payment_id text UNIQUE NOT NULL,
  razorpay_signature text NOT NULL,
  amount numeric(10,2) NOT NULL,
  currency text DEFAULT 'INR',
  status text CHECK (status IN ('success', 'failed', 'captured', 'refunded', 'partially_refunded')) DEFAULT 'success',
  payment_method text,
  failure_reason text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Refunds Table
CREATE TABLE IF NOT EXISTS refunds (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  razorpay_refund_id text UNIQUE NOT NULL,
  razorpay_payment_id text NOT NULL,
  amount numeric(10,2) NOT NULL,
  currency text DEFAULT 'INR',
  status text CHECK (status IN ('pending', 'processed', 'failed')) DEFAULT 'pending',
  notes jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Payment Logs Table
CREATE TABLE IF NOT EXISTS payment_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  razorpay_order_id text,
  razorpay_payment_id text,
  booking_id uuid,
  status text NOT NULL,
  error_message text,
  metadata jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now()
);

-- Webhook Logs Table
CREATE TABLE IF NOT EXISTS webhook_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  event_type text NOT NULL,
  razorpay_payment_id text,
  razorpay_order_id text,
  status text CHECK (status IN ('received', 'processed', 'failed')) DEFAULT 'received',
  payload jsonb,
  error_message text,
  created_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE payment_orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE payments ENABLE ROW LEVEL SECURITY;
ALTER TABLE refunds ENABLE ROW LEVEL SECURITY;
ALTER TABLE payment_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE webhook_logs ENABLE ROW LEVEL SECURITY;

-- RLS Policies for payment_orders
CREATE POLICY "Users can view their own payment orders"
  ON payment_orders
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM bookings b
      WHERE b.user_id = auth.uid()
      AND payment_orders.receipt LIKE '%' || b.id::text || '%'
    )
  );

-- RLS Policies for payments
CREATE POLICY "Users can view their own payments"
  ON payments
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM bookings b
      WHERE b.user_id = auth.uid()
      AND b.id = payments.booking_id
    )
  );

-- RLS Policies for refunds
CREATE POLICY "Users can view their own refunds"
  ON refunds
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM payments p
      JOIN bookings b ON b.id = p.booking_id
      WHERE b.user_id = auth.uid()
      AND p.razorpay_payment_id = refunds.razorpay_payment_id
    )
  );

-- Admin policies (for service role)
CREATE POLICY "Service role can manage all payment data"
  ON payment_orders
  FOR ALL
  TO service_role
  USING (true);

CREATE POLICY "Service role can manage all payments"
  ON payments
  FOR ALL
  TO service_role
  USING (true);

CREATE POLICY "Service role can manage all refunds"
  ON refunds
  FOR ALL
  TO service_role
  USING (true);

CREATE POLICY "Service role can manage all payment logs"
  ON payment_logs
  FOR ALL
  TO service_role
  USING (true);

CREATE POLICY "Service role can manage all webhook logs"
  ON webhook_logs
  FOR ALL
  TO service_role
  USING (true);

-- Indexes for better performance
CREATE INDEX IF NOT EXISTS idx_payment_orders_razorpay_order_id ON payment_orders(razorpay_order_id);
CREATE INDEX IF NOT EXISTS idx_payments_booking_id ON payments(booking_id);
CREATE INDEX IF NOT EXISTS idx_payments_razorpay_payment_id ON payments(razorpay_payment_id);
CREATE INDEX IF NOT EXISTS idx_refunds_razorpay_payment_id ON refunds(razorpay_payment_id);
CREATE INDEX IF NOT EXISTS idx_payment_logs_created_at ON payment_logs(created_at);
CREATE INDEX IF NOT EXISTS idx_webhook_logs_created_at ON webhook_logs(created_at);