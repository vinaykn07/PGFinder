import { createClient } from 'npm:@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization',
};

interface RefundRequest {
  payment_id: string;
  amount?: number; // Optional for partial refunds
  notes?: Record<string, string>;
}

Deno.serve(async (req: Request) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    // Initialize Supabase client
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    const { payment_id, amount, notes }: RefundRequest = await req.json();

    if (!payment_id) {
      return new Response(
        JSON.stringify({ error: 'Payment ID is required' }),
        {
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      );
    }

    // Get Razorpay credentials
    const razorpayKeyId = Deno.env.get('RAZORPAY_KEY_ID');
    const razorpayKeySecret = Deno.env.get('RAZORPAY_KEY_SECRET');

    if (!razorpayKeyId || !razorpayKeySecret) {
      throw new Error('Razorpay credentials not configured');
    }

    // Prepare refund data
    const refundData: any = {
      notes: notes || {},
    };

    // Add amount for partial refund
    if (amount) {
      refundData.amount = amount * 100; // Convert to paise
    }

    // Create refund via Razorpay API
    const response = await fetch(`https://api.razorpay.com/v1/payments/${payment_id}/refund`, {
      method: 'POST',
      headers: {
        'Authorization': `Basic ${btoa(`${razorpayKeyId}:${razorpayKeySecret}`)}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(refundData),
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(`Razorpay refund error: ${errorData.error?.description || 'Unknown error'}`);
    }

    const refund = await response.json();

    // Store refund record in database
    const { error: dbError } = await supabaseClient
      .from('refunds')
      .insert({
        razorpay_refund_id: refund.id,
        razorpay_payment_id: payment_id,
        amount: refund.amount / 100, // Convert from paise to rupees
        currency: refund.currency,
        status: refund.status,
        notes: refund.notes,
        created_at: new Date().toISOString(),
      });

    if (dbError) {
      console.error('Database error storing refund:', dbError);
    }

    // Update payment status
    await supabaseClient
      .from('payments')
      .update({
        status: amount ? 'partially_refunded' : 'refunded',
        updated_at: new Date().toISOString(),
      })
      .eq('razorpay_payment_id', payment_id);

    // Update booking status if full refund
    if (!amount) {
      const { data: paymentData } = await supabaseClient
        .from('payments')
        .select('booking_id')
        .eq('razorpay_payment_id', payment_id)
        .single();

      if (paymentData?.booking_id) {
        await supabaseClient
          .from('bookings')
          .update({
            status: 'cancelled',
            payment_status: 'refunded',
            updated_at: new Date().toISOString(),
          })
          .eq('id', paymentData.booking_id);
      }
    }

    return new Response(
      JSON.stringify({
        success: true,
        refund_id: refund.id,
        amount: refund.amount / 100,
        status: refund.status,
      }),
      {
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  } catch (error) {
    console.error('Error processing refund:', error);
    
    return new Response(
      JSON.stringify({ 
        success: false,
        error: 'Refund processing failed',
        details: error instanceof Error ? error.message : 'Unknown error'
      }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});