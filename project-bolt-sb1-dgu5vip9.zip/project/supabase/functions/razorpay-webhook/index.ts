import { createClient } from 'npm:@supabase/supabase-js@2';
import { createHmac } from 'node:crypto';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Razorpay-Signature',
};

Deno.serve(async (req: Request) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    // Initialize Supabase client
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    const body = await req.text();
    const signature = req.headers.get('X-Razorpay-Signature');

    if (!signature) {
      return new Response('Missing signature', { status: 400 });
    }

    // Verify webhook signature
    const webhookSecret = Deno.env.get('RAZORPAY_WEBHOOK_SECRET');
    if (!webhookSecret) {
      throw new Error('Webhook secret not configured');
    }

    const expectedSignature = createHmac('sha256', webhookSecret)
      .update(body)
      .digest('hex');

    if (expectedSignature !== signature) {
      console.error('Invalid webhook signature');
      return new Response('Invalid signature', { status: 400 });
    }

    const event = JSON.parse(body);
    console.log('Webhook event:', event.event);

    // Handle different webhook events
    switch (event.event) {
      case 'payment.captured':
        await handlePaymentCaptured(supabaseClient, event.payload.payment.entity);
        break;
      
      case 'payment.failed':
        await handlePaymentFailed(supabaseClient, event.payload.payment.entity);
        break;
      
      case 'order.paid':
        await handleOrderPaid(supabaseClient, event.payload.order.entity);
        break;
      
      default:
        console.log(`Unhandled webhook event: ${event.event}`);
    }

    // Log webhook event
    await supabaseClient
      .from('webhook_logs')
      .insert({
        event_type: event.event,
        razorpay_payment_id: event.payload.payment?.entity?.id,
        razorpay_order_id: event.payload.order?.entity?.id,
        status: 'processed',
        created_at: new Date().toISOString(),
      });

    return new Response('OK', {
      status: 200,
      headers: corsHeaders,
    });
  } catch (error) {
    console.error('Webhook processing error:', error);
    
    return new Response(
      JSON.stringify({ error: 'Webhook processing failed' }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});

async function handlePaymentCaptured(supabaseClient: any, payment: any) {
  try {
    // Update payment status
    await supabaseClient
      .from('payments')
      .update({
        status: 'captured',
        updated_at: new Date().toISOString(),
      })
      .eq('razorpay_payment_id', payment.id);

    // Update booking status if not already confirmed
    const { data: bookingData } = await supabaseClient
      .from('payments')
      .select('booking_id')
      .eq('razorpay_payment_id', payment.id)
      .single();

    if (bookingData?.booking_id) {
      await supabaseClient
        .from('bookings')
        .update({
          status: 'confirmed',
          payment_status: 'paid',
          updated_at: new Date().toISOString(),
        })
        .eq('id', bookingData.booking_id);
    }

    console.log(`Payment captured: ${payment.id}`);
  } catch (error) {
    console.error('Error handling payment captured:', error);
  }
}

async function handlePaymentFailed(supabaseClient: any, payment: any) {
  try {
    // Update payment status
    await supabaseClient
      .from('payments')
      .update({
        status: 'failed',
        failure_reason: payment.error_description,
        updated_at: new Date().toISOString(),
      })
      .eq('razorpay_payment_id', payment.id);

    // Update booking status
    const { data: bookingData } = await supabaseClient
      .from('payments')
      .select('booking_id')
      .eq('razorpay_payment_id', payment.id)
      .single();

    if (bookingData?.booking_id) {
      await supabaseClient
        .from('bookings')
        .update({
          payment_status: 'failed',
          updated_at: new Date().toISOString(),
        })
        .eq('id', bookingData.booking_id);
    }

    console.log(`Payment failed: ${payment.id}`);
  } catch (error) {
    console.error('Error handling payment failed:', error);
  }
}

async function handleOrderPaid(supabaseClient: any, order: any) {
  try {
    // Update order status
    await supabaseClient
      .from('payment_orders')
      .update({
        status: 'paid',
        updated_at: new Date().toISOString(),
      })
      .eq('razorpay_order_id', order.id);

    console.log(`Order paid: ${order.id}`);
  } catch (error) {
    console.error('Error handling order paid:', error);
  }
}