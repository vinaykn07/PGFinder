import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Modal,
  TouchableOpacity,
  Alert,
  ActivityIndicator,
  Image,
} from 'react-native';
import { X, CreditCard, Smartphone, Building2, Wallet } from 'lucide-react-native';
import PaymentService from '@/services/paymentService';
import { PaymentOptions } from '@/types/payment';

interface PaymentModalProps {
  visible: boolean;
  onClose: () => void;
  bookingDetails: {
    pgName: string;
    amount: number;
    bookingId: string;
    userId: string;
    userEmail: string;
    userPhone: string;
    userName: string;
  };
  onPaymentSuccess: (paymentData: any) => void;
  onPaymentFailure: (error: any) => void;
}

export const PaymentModal: React.FC<PaymentModalProps> = ({
  visible,
  onClose,
  bookingDetails,
  onPaymentSuccess,
  onPaymentFailure,
}) => {
  const [isProcessing, setIsProcessing] = useState(false);
  const [selectedMethod, setSelectedMethod] = useState<string>('upi');

  const paymentMethods = [
    { id: 'upi', name: 'UPI', icon: Smartphone, description: 'GPay, PhonePe, Paytm' },
    { id: 'card', name: 'Cards', icon: CreditCard, description: 'Credit/Debit Cards' },
    { id: 'netbanking', name: 'Net Banking', icon: Building2, description: 'All Major Banks' },
    { id: 'wallet', name: 'Wallets', icon: Wallet, description: 'Paytm, Mobikwik' },
  ];

  const handlePayment = async () => {
    try {
      setIsProcessing(true);

      // Step 1: Create order on backend
      const order = await PaymentService.createOrder(
        bookingDetails.amount,
        'INR',
        `booking_${bookingDetails.bookingId}`,
        {
          booking_id: bookingDetails.bookingId,
          user_id: bookingDetails.userId,
          pg_name: bookingDetails.pgName,
        }
      );

      // Step 2: Prepare payment options
      const paymentOptions: PaymentOptions = {
        description: `Payment for ${bookingDetails.pgName}`,
        image: 'https://images.pexels.com/photos/271795/pexels-photo-271795.jpeg?auto=compress&cs=tinysrgb&w=100',
        currency: 'INR',
        key: process.env.EXPO_PUBLIC_RAZORPAY_KEY_ID || '',
        amount: bookingDetails.amount * 100, // Convert to paise
        order_id: order.id,
        name: 'PG Finder',
        prefill: {
          email: bookingDetails.userEmail,
          contact: bookingDetails.userPhone,
          name: bookingDetails.userName,
        },
        theme: {
          color: '#FF6B35',
        },
      };

      // Step 3: Open Razorpay checkout
      const paymentData = await PaymentService.initiatePayment(paymentOptions);

      // Step 4: Verify payment on backend
      const verificationResult = await PaymentService.verifyPayment(
        paymentData.razorpay_order_id,
        paymentData.razorpay_payment_id,
        paymentData.razorpay_signature,
        bookingDetails.bookingId
      );

      if (verificationResult.success) {
        onPaymentSuccess(paymentData);
        onClose();
      } else {
        throw new Error('Payment verification failed');
      }
    } catch (error: any) {
      console.error('Payment error:', error);
      
      if (error.code === 'payment_cancelled') {
        // User cancelled payment
        Alert.alert('Payment Cancelled', 'You cancelled the payment process.');
      } else if (error.code === 'payment_failed') {
        // Payment failed
        Alert.alert('Payment Failed', error.description || 'Payment could not be processed. Please try again.');
      } else {
        // Other errors
        Alert.alert('Payment Error', 'Something went wrong. Please try again.');
      }
      
      onPaymentFailure(error);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleOfflinePayment = () => {
    Alert.alert(
      'Offline Payment',
      'You can pay directly to the PG owner and update the payment status later. Contact the owner for bank details.',
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Contact Owner', onPress: () => {/* Navigate to contact */ } },
      ]
    );
  };

  return (
    <Modal visible={visible} animationType="slide" presentationStyle="pageSheet">
      <View style={styles.container}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.title}>Complete Payment</Text>
          <TouchableOpacity onPress={onClose} style={styles.closeButton}>
            <X size={24} color="#666" />
          </TouchableOpacity>
        </View>

        {/* Booking Summary */}
        <View style={styles.summaryCard}>
          <Text style={styles.pgName}>{bookingDetails.pgName}</Text>
          <View style={styles.amountRow}>
            <Text style={styles.amountLabel}>Total Amount</Text>
            <Text style={styles.amount}>₹{bookingDetails.amount.toLocaleString()}</Text>
          </View>
          <Text style={styles.bookingId}>Booking ID: {bookingDetails.bookingId}</Text>
        </View>

        {/* Payment Methods */}
        <View style={styles.methodsContainer}>
          <Text style={styles.sectionTitle}>Choose Payment Method</Text>
          {paymentMethods.map((method) => (
            <TouchableOpacity
              key={method.id}
              style={[
                styles.methodCard,
                selectedMethod === method.id && styles.selectedMethod,
              ]}
              onPress={() => setSelectedMethod(method.id)}
            >
              <View style={styles.methodLeft}>
                <View style={[
                  styles.methodIcon,
                  selectedMethod === method.id && styles.selectedMethodIcon,
                ]}>
                  <method.icon size={20} color={selectedMethod === method.id ? 'white' : '#666'} />
                </View>
                <View>
                  <Text style={styles.methodName}>{method.name}</Text>
                  <Text style={styles.methodDescription}>{method.description}</Text>
                </View>
              </View>
              <View style={[
                styles.radioButton,
                selectedMethod === method.id && styles.radioButtonSelected,
              ]} />
            </TouchableOpacity>
          ))}
        </View>

        {/* Security Info */}
        <View style={styles.securityInfo}>
          <Text style={styles.securityText}>
            🔒 Your payment is secured by 256-bit SSL encryption
          </Text>
        </View>

        {/* Action Buttons */}
        <View style={styles.actionContainer}>
          <TouchableOpacity
            style={styles.payButton}
            onPress={handlePayment}
            disabled={isProcessing}
          >
            {isProcessing ? (
              <ActivityIndicator color="white" />
            ) : (
              <Text style={styles.payButtonText}>
                Pay ₹{bookingDetails.amount.toLocaleString()}
              </Text>
            )}
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.offlineButton}
            onPress={handleOfflinePayment}
          >
            <Text style={styles.offlineButtonText}>Pay Offline</Text>
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8f9fa',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    backgroundColor: 'white',
    borderBottomWidth: 1,
    borderBottomColor: '#e0e0e0',
  },
  title: {
    fontSize: 20,
    fontWeight: '600',
    color: '#2d3748',
  },
  closeButton: {
    padding: 4,
  },
  summaryCard: {
    backgroundColor: 'white',
    margin: 20,
    padding: 20,
    borderRadius: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  pgName: {
    fontSize: 18,
    fontWeight: '600',
    color: '#2d3748',
    marginBottom: 12,
  },
  amountRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  amountLabel: {
    fontSize: 16,
    color: '#666',
  },
  amount: {
    fontSize: 24,
    fontWeight: '700',
    color: '#FF6B35',
  },
  bookingId: {
    fontSize: 12,
    color: '#999',
  },
  methodsContainer: {
    paddingHorizontal: 20,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#2d3748',
    marginBottom: 16,
  },
  methodCard: {
    backgroundColor: 'white',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: 'transparent',
  },
  selectedMethod: {
    borderColor: '#FF6B35',
    backgroundColor: '#fff5f2',
  },
  methodLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  methodIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#f8f9fa',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  selectedMethodIcon: {
    backgroundColor: '#FF6B35',
  },
  methodName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#2d3748',
    marginBottom: 2,
  },
  methodDescription: {
    fontSize: 12,
    color: '#666',
  },
  radioButton: {
    width: 20,
    height: 20,
    borderRadius: 10,
    borderWidth: 2,
    borderColor: '#ccc',
  },
  radioButtonSelected: {
    borderColor: '#FF6B35',
    backgroundColor: '#FF6B35',
  },
  securityInfo: {
    paddingHorizontal: 20,
    marginTop: 20,
  },
  securityText: {
    fontSize: 12,
    color: '#666',
    textAlign: 'center',
  },
  actionContainer: {
    padding: 20,
    marginTop: 'auto',
  },
  payButton: {
    backgroundColor: '#FF6B35',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    marginBottom: 12,
  },
  payButtonText: {
    color: 'white',
    fontSize: 18,
    fontWeight: '600',
  },
  offlineButton: {
    backgroundColor: 'transparent',
    borderWidth: 1,
    borderColor: '#FF6B35',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
  },
  offlineButtonText: {
    color: '#FF6B35',
    fontSize: 16,
    fontWeight: '600',
  },
});