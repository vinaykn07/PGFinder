import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Image } from 'react-native';
import { MapPin, Star, Wifi, Car, Coffee, Shield } from 'lucide-react-native';

interface PGCardProps {
  pg: {
    id: number;
    name: string;
    location: string;
    price: number;
    rating: number;
    reviews: number;
    image: string;
    amenities: string[];
    type: string;
  };
  onPress?: () => void;
}

export const PGCard: React.FC<PGCardProps> = ({ pg, onPress }) => {
  const getAmenityIcon = (amenity: string) => {
    switch (amenity) {
      case 'WiFi':
        return <Wifi size={14} color="#00A896" />;
      case 'Parking':
        return <Car size={14} color="#00A896" />;
      case 'Meals':
        return <Coffee size={14} color="#00A896" />;
      case 'Security':
        return <Shield size={14} color="#00A896" />;
      default:
        return null;
    }
  };

  return (
    <TouchableOpacity style={styles.card} onPress={onPress}>
      <Image source={{ uri: pg.image }} style={styles.image} />
      <View style={styles.info}>
        <View style={styles.header}>
          <Text style={styles.name}>{pg.name}</Text>
          <Text style={styles.type}>{pg.type}</Text>
        </View>
        
        <View style={styles.locationRow}>
          <MapPin size={14} color="#666" />
          <Text style={styles.location}>{pg.location}</Text>
        </View>

        <View style={styles.amenitiesRow}>
          {pg.amenities.slice(0, 4).map((amenity, index) => (
            <View key={index} style={styles.amenityItem}>
              {getAmenityIcon(amenity)}
              <Text style={styles.amenityText}>{amenity}</Text>
            </View>
          ))}
        </View>

        <View style={styles.footer}>
          <View style={styles.ratingContainer}>
            <Star size={14} color="#FFD700" fill="#FFD700" />
            <Text style={styles.rating}>{pg.rating}</Text>
            <Text style={styles.reviewCount}>({pg.reviews} reviews)</Text>
          </View>
          <View style={styles.priceContainer}>
            <Text style={styles.price}>₹{pg.price.toLocaleString()}</Text>
            <Text style={styles.priceLabel}>/month</Text>
          </View>
        </View>
      </View>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  card: {
    backgroundColor: 'white',
    borderRadius: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
    overflow: 'hidden',
  },
  image: {
    width: '100%',
    height: 200,
    resizeMode: 'cover',
  },
  info: {
    padding: 16,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  name: {
    fontSize: 18,
    fontWeight: '600',
    color: '#2d3748',
    flex: 1,
  },
  type: {
    backgroundColor: '#FF6B35',
    color: 'white',
    fontSize: 12,
    fontWeight: '500',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
  },
  locationRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  location: {
    fontSize: 14,
    color: '#666',
    marginLeft: 6,
  },
  amenitiesRow: {
    flexDirection: 'row',
    gap: 16,
    marginBottom: 16,
  },
  amenityItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  amenityText: {
    fontSize: 12,
    color: '#666',
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  rating: {
    fontSize: 14,
    fontWeight: '600',
    color: '#2d3748',
  },
  reviewCount: {
    fontSize: 12,
    color: '#666',
  },
  priceContainer: {
    flexDirection: 'row',
    alignItems: 'baseline',
    gap: 2,
  },
  price: {
    fontSize: 20,
    fontWeight: '700',
    color: '#FF6B35',
  },
  priceLabel: {
    fontSize: 12,
    color: '#666',
  },
});