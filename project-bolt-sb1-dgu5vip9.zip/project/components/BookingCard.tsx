import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Image,
  Alert,
} from 'react-native';
import { MapPin, Calendar, Users, CreditCard } from 'lucide-react-native';
import { PaymentModal } from './PaymentModal';

interface BookingCardProps {
  pg: {
    id: number;
    name: string;
    location: string;
    price: number;
    image: string;
    type: string;
  };
  user: {
    id: string;
    email: string;
    phone: string;
    name: string;
  };
}

export const BookingCard: React.FC<BookingCardProps> = ({ pg, user }) => {
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [isBooking, setIsBooking] = useState(false);

  const handleBookNow = () => {
    setShowPaymentModal(true);
  };

  const handlePaymentSuccess = (paymentData: any) => {
    Alert.alert(
      'Payment Successful!',
      `Your booking for ${pg.name} has been confirmed. Payment ID: ${paymentData.razorpay_payment_id}`,
      [
        {
          text: 'OK',
          onPress: () => {
            // Navigate to bookings screen or refresh data
            console.log('Payment successful:', paymentData);
          },
        },
      ]
    );
  };

  const handlePaymentFailure = (error: any) => {
    console.error('Payment failed:', error);
    // Error handling is already done in PaymentModal
  };

  const bookingDetails = {
    pgName: pg.name,
    amount: pg.price + 2000, // Including security deposit
    bookingId: `BK${Date.now()}`,
    userId: user.id,
    userEmail: user.email,
    userPhone: user.phone,
    userName: user.name,
  };

  return (
    <>
      <View style={styles.card}>
        <Image source={{ uri: pg.image }} style={styles.image} />
        <View style={styles.info}>
          <View style={styles.header}>
            <Text style={styles.name}>{pg.name}</Text>
            <Text style={styles.type}>{pg.type}</Text>
          </View>
          
          <View style={styles.locationRow}>
            <MapPin size={14} color="#666" />
            <Text style={styles.location}>{pg.location}</Text>
          </View>

          <View style={styles.detailsRow}>
            <View style={styles.detail}>
              <Calendar size={16} color="#FF6B35" />
              <Text style={styles.detailText}>Available Now</Text>
            </View>
            <View style={styles.detail}>
              <Users size={16} color="#FF6B35" />
              <Text style={styles.detailText}>2-3 Sharing</Text>
            </View>
          </View>

          <View style={styles.pricingContainer}>
            <View style={styles.priceBreakdown}>
              <View style={styles.priceRow}>
                <Text style={styles.priceLabel}>Monthly Rent</Text>
                <Text style={styles.priceValue}>₹{pg.price.toLocaleString()}</Text>
              </View>
              <View style={styles.priceRow}>
                <Text style={styles.priceLabel}>Security Deposit</Text>
                <Text style={styles.priceValue}>₹2,000</Text>
              </View>
              <View style={[styles.priceRow, styles.totalRow]}>
                <Text style={styles.totalLabel}>Total Amount</Text>
                <Text style={styles.totalAmount}>₹{(pg.price + 2000).toLocaleString()}</Text>
              </View>
            </View>
          </View>

          <TouchableOpacity
            style={styles.bookButton}
            onPress={handleBookNow}
            disabled={isBooking}
          >
            <CreditCard size={20} color="white" />
            <Text style={styles.bookButtonText}>
              {isBooking ? 'Processing...' : 'Book Now & Pay'}
            </Text>
          </TouchableOpacity>
        </View>
      </View>

      <PaymentModal
        visible={showPaymentModal}
        onClose={() => setShowPaymentModal(false)}
        bookingDetails={bookingDetails}
        onPaymentSuccess={handlePaymentSuccess}
        onPaymentFailure={handlePaymentFailure}
      />
    </>
  );
};

const styles = StyleSheet.create({
  card: {
    backgroundColor: 'white',
    borderRadius: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
    overflow: 'hidden',
  },
  image: {
    width: '100%',
    height: 200,
    resizeMode: 'cover',
  },
  info: {
    padding: 16,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  name: {
    fontSize: 18,
    fontWeight: '600',
    color: '#2d3748',
    flex: 1,
  },
  type: {
    backgroundColor: '#FF6B35',
    color: 'white',
    fontSize: 12,
    fontWeight: '500',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
  },
  locationRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  location: {
    fontSize: 14,
    color: '#666',
    marginLeft: 6,
  },
  detailsRow: {
    flexDirection: 'row',
    gap: 20,
    marginBottom: 16,
  },
  detail: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  detailText: {
    fontSize: 12,
    color: '#666',
    fontWeight: '500',
  },
  pricingContainer: {
    backgroundColor: '#f8f9fa',
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
  },
  priceBreakdown: {
    gap: 8,
  },
  priceRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  priceLabel: {
    fontSize: 14,
    color: '#666',
  },
  priceValue: {
    fontSize: 14,
    fontWeight: '500',
    color: '#2d3748',
  },
  totalRow: {
    borderTopWidth: 1,
    borderTopColor: '#e0e0e0',
    paddingTop: 8,
    marginTop: 4,
  },
  totalLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: '#2d3748',
  },
  totalAmount: {
    fontSize: 18,
    fontWeight: '700',
    color: '#FF6B35',
  },
  bookButton: {
    backgroundColor: '#FF6B35',
    borderRadius: 12,
    padding: 16,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 8,
  },
  bookButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: '600',
  },
});